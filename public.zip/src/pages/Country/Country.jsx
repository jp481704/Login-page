import axios from "axios";  // Importing axios for making HTTP requests
import React, { useEffect, useState } from "react"; // Importing React hooks
import config from "../../config/config"; // Configuration for the API
import userApi from "../../config/userApi"; // API paths
import Select from "../../components/Form/Select"; // A custom Select component

const Country = () => {
  // State variables to hold data for countries, states, cities, and user selections
  const [countryData, setCountryData] = useState([]);  // List of countries
  const [stateData, setStateData] = useState([]);  // List of states based on selected country
  const [cityData, setCityData] = useState([]);  // List of cities based on selected state

  const [countryId, setCountryId] = useState("");  // Selected country ID
  const [stateId, setStateId] = useState("");  // Selected state ID
  const [cityId, setCityId] = useState("");  // Selected city ID

  const [submittedData, setSubmittedData] = useState([]);  // Submitted form data
  const [editId, setEditId] = useState(null);  // ID of the entry being edited (null if no entry is being edited)

  // Fetch token from localStorage for API authorization
  const token = localStorage.getItem("token");
  const headers = {
    Authorization: `Bearer ${token}`,  // Bearer token for authorization in headers
  };

  // On initial load, fetch any previously submitted data from localStorage
  useEffect(() => {
    const storedData = JSON.parse(localStorage.getItem("submittedData"));
    if (storedData) {
      setSubmittedData(storedData);  // Update state with stored data
    }
  }, []);

  // Fetch countries from the API when the component mounts
  useEffect(() => {
    const fetchCountries = async () => {
      try {
        const res = await axios.get(`${config.URL}${userApi.country}`, {
          headers,
        });
        setCountryData(res.data.data);  // Set country data state with the API response
      } catch (err) {
        console.error("Error fetching countries:", err);  // Log error if fetching countries fails
      }
    };
    fetchCountries();
  }, []);

  // Fetch states based on selected countryId
  useEffect(() => {
    if (countryId) {  // Fetch states only if a country is selected
      const fetchStates = async () => {
        try {
          const res = await axios.get(
            `http://134.209.155.122:8087/api/v1/states?countryId=${countryId}`,
            { headers }
          );
          setStateData(res.data.data);  // Set state data state with the API response
        } catch (err) {
          console.error("Error fetching states:", err);  // Log error if fetching states fails
        }
      };
      fetchStates();
    } else {
      setStateData([]);  // If no country is selected, reset states
      setStateId("");  // Reset selected state
    }
  }, [countryId]);  // This effect runs when countryId changes

  // Fetch cities based on selected stateId
  useEffect(() => {
    if (stateId) {  // Fetch cities only if a state is selected
      const fetchCities = async () => {
        try {
          const res = await axios.get(
            `http://134.209.155.122:8087/api/v1/cities?stateId=${stateId}`,
            { headers }
          );
          setCityData(res.data.data);  // Set city data state with the API response
        } catch (err) {
          console.error("Error fetching cities:", err);  // Log error if fetching cities fails
        }
      };
      fetchCities();
    } else {
      setCityData([]);  // If no state is selected, reset cities
      setCityId("");  // Reset selected city
    }
  }, [stateId]);  // This effect runs when stateId changes

  // Handle form submission for adding new data
  const handleSubmit = (e) => {
    e.preventDefault();  // Prevent the default form submission behavior

    // Find the selected country, state, and city from their respective data
    const selectedCountry = countryData.find((c) => c.countryId == countryId);
    const selectedState = stateData.find((s) => s.stateId == stateId);
    const selectedCity = cityData.find((c) => c.cityId == cityId);

    // Ensure the user selects country, state, and city
    if (!selectedCountry || !selectedState || !selectedCity) {
      alert("Please select Country, State and City");
      return;
    }

    // Create a new entry with current selections
    const newEntry = {
      id: Date.now(),  // Unique ID based on current timestamp
      country: selectedCountry.countryName,
      state: selectedState.stateName,
      city: selectedCity.cityName,
    };

    // Update the submitted data array
    const updatedData = [...submittedData, newEntry];
    setSubmittedData(updatedData);  // Set the new submitted data in state

    // Store the updated data in localStorage
    localStorage.setItem("submittedData", JSON.stringify(updatedData));

    // Reset the select inputs
    setCountryId("");
    setStateId("");
    setCityId("");
  };

  // Handle deleting a submitted entry
  const handleDelete = (id) => {
    const updatedData = submittedData.filter((entry) => entry.id !== id);  // Filter out the deleted entry
    setSubmittedData(updatedData);  // Update the state with the new list of submitted data

    // Update localStorage with the new data
    localStorage.setItem("submittedData", JSON.stringify(updatedData));
  };

  // Handle editing an existing entry
  const handleEdit = (id) => {
    const entryToEdit = submittedData.find((entry) => entry.id === id);
    // Set the select inputs with the values from the entry to be edited
    setCountryId(entryToEdit.countryId);  // Set the selected country to the current entry's countryId
    setStateId(entryToEdit.stateId);  // Set the selected state to the current entry's stateId
    setCityId(entryToEdit.cityId);  // Set the selected city to the current entry's cityId
    setEditId(id);  // Store the editId to know which entry is being edited
  };

  // Handle saving the edited data
  const handleSaveEdit = (e) => {
    e.preventDefault();  // Prevent default form submission behavior

    // Find the selected country, state, and city from their respective data
    const selectedCountry = countryData.find((c) => c.countryId == countryId);
    const selectedState = stateData.find((s) => s.stateId == stateId);
    const selectedCity = cityData.find((c) => c.cityId == cityId);

    // Ensure the user selects country, state, and city
    if (!selectedCountry || !selectedState || !selectedCity) {
      alert("Please select Country, State and City");
      return;
    }

    // Map through the submitted data and update the edited entry
    const updatedData = submittedData.map((entry) =>
      entry.id === editId
        ? {
            ...entry,
            country: selectedCountry.countryName,  // Keep the country the same
            state: selectedState.stateName,  // Keep the state the same
            city: selectedCity.cityName,  // Update only the city
          }
        : entry
    );

    // Update the state with the new list of submitted data
    setSubmittedData(updatedData);

    // Update localStorage with the new data
    localStorage.setItem("submittedData", JSON.stringify(updatedData));

    // Reset the form and editId after saving
    setCountryId("");
    setStateId("");
    setCityId("");
    setEditId(null);  // Reset edit mode
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Location Selection</h2>

      {/* Form for selecting country, state, and city */}
      <form onSubmit={editId ? handleSaveEdit : handleSubmit} className="space-y-4">
        <Select
          label="Country"
          id="country"
          name="country"
          value={countryId}
          onChange={(e) => setCountryId(e.target.value)}  // Update countryId on change
          country_option={countryData.map((country) => ({
            id: country.countryId,
            name: country.countryName,
          }))}  // Map countryData to select options
        />

        <Select
          label="State"
          id="state"
          name="state"
          value={stateId}
          onChange={(e) => setStateId(e.target.value)}  // Update stateId on change
          disabled={!countryId}  // Disable the state select if no country is selected
          country_option={stateData.map((state) => ({
            id: state.stateId,
            name: state.stateName,
          }))}  // Map stateData to select options
        />

        <Select
          label="City"
          id="city"
          name="city"
          value={cityId}
          onChange={(e) => setCityId(e.target.value)}  // Update cityId on change
          disabled={!stateId}  // Disable the city select if no state is selected
          country_option={cityData.map((city) => ({
            id: city.cityId,
            name: city.cityName,
          }))}  // Map cityData to select options
        />

        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
          {editId ? "Save Changes" : "Submit"}  {/* Change button text if editing */}
        </button>
      </form>

      {/* Display submitted data in a table */}
      {submittedData.length > 0 && (
        <div className="mt-6 overflow-x-auto">
          <h3 className="text-lg font-semibold mb-4">Submitted Locations</h3>
          <table className="min-w-full border border-gray-300 shadow-lg rounded-lg">
            <thead className="bg-blue-600 text-white">
              <tr>
                <th className="border p-3 text-left">Country</th>
                <th className="border p-3 text-left">State</th>
                <th className="border p-3 text-left">City</th>
                <th className="border p-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {submittedData.map((entry) => (
                <tr key={entry.id} className="bg-white hover:bg-gray-100">
                  <td className="border p-3">{entry.country}</td>
                  <td className="border p-3">{entry.state}</td>
                  <td className="border p-3">{entry.city}</td>
                  <td className="border p-3">
                    <button
                      onClick={() => handleEdit(entry.id)}  // Trigger editing for this entry
                      className="bg-yellow-400 text-white px-4 py-1 rounded mr-2"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(entry.id)}  // Delete this entry
                      className="bg-red-600 text-white px-4 py-1 rounded"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Country;
