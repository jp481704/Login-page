const config = {
URL :"http://134.209.155.122:8087/api/v1/"
}

export default config