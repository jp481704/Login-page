const userApi = {
    userLogin :"auth",
    country:"country",
    state:"states",
    city:"cities"
}
export default userApi