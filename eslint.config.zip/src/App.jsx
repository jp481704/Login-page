import React from 'react'
import { useState } from 'react'
import './App.css'
import Login from './pages/login/Login'

function App() {

  return (
    <>
      <Login/>
    </>
  )
}

export default App
